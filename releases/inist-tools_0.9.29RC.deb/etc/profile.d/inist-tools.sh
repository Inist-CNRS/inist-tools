export PATH="$PATH:/opt/inist-tools"
. /opt/inist-tools/inistrc
